from setuptools import setup, find_packages

setup(
    name="utils",
    version="0.1.0",
    packages=find_packages(include=["utils", "utils.*"]),
    python_requires=">=3.8",
    install_requires=[],
)

